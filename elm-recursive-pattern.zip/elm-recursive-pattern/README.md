# Recursive-Pattern-Technique

This work is not a package yet. Once it has been converted to a package and uploaded to a Github-Repository, these instructions can be followed:

## Getting started

You will need to have [elm](https://elm-lang.org) installed. Then run:

```sh
elm init
elm install [repoName]/elm-recursive-pattern
```
The [Create-Elm-App-Package](https://github.com/halfzebra/create-elm-app) was used for development.

Of course, Elm Reaktor or Elm make can also be used.


## What's included?

### RecursivePattern

This module provides arrangement functions for the user as well as some types and helper-functions to be able to work with.

### RecursivePattern.Helper

This module provides functions that help the user to display the created pixel positions.


This module can only be used if [elm-visualization](http://package.elm-lang.org/packages/gampleman/elm-visualization/latest/) has also been installed.

## Contributing

This package was created in the context of a bachelor thesis.