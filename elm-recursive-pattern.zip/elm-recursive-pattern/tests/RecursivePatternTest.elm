module RecursivePatternTest exposing (..)

import Expect
import RecursivePattern
import Scale exposing (ContinuousScale)
import Test exposing (..)
import TypedSvg.Attributes
import TypedSvg.Types exposing (px)



-- Check out https://package.elm-lang.org/packages/elm-explorations/test/latest to learn more about testing in Elm!


all : Test
all =
    describe "A Test Suite for RecursivePattern"
        [ describe "First Method"
            [ test "startPosition" <|
                \() ->
                    RecursivePattern.startPosition
                        |> Expect.equal (RecursivePattern.PixelPositon 0 0)
            ]
        , describe "Augment Level"
            [ test "augementLevel with empty Level" <|
                let
                    levels =
                        []
                in
                \() ->
                    RecursivePattern.augementLevel levels
                        |> Expect.equal [ ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]
            , test "augementLevel" <|
                let
                    levels =
                        [ RecursivePattern.Level 0 0 ]
                in
                \() ->
                    RecursivePattern.augementLevel levels
                        |> Expect.equal [ ( RecursivePattern.Level 0 0, RecursivePattern.Level 1 1 ), ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]
            , test "augementLevel 2" <|
                let
                    levels =
                        [ RecursivePattern.Level 2 2 ]
                in
                \() ->
                    RecursivePattern.augementLevel levels
                        |> Expect.equal [ ( RecursivePattern.Level 2 2, RecursivePattern.Level 1 1 ), ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]
            , test "augementLevel 3" <|
                let
                    levels =
                        [ RecursivePattern.Level 3 3 ]
                in
                \() ->
                    RecursivePattern.augementLevel levels
                        |> Expect.equal [ ( RecursivePattern.Level 3 3, RecursivePattern.Level 1 1 ), ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]
            ]
        , describe "createPixelMap"
            [ test "createPixelMap with empty Level" <|
                let
                    levels =
                        []

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMap pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0 ]
            , test "createPixelMap with Level" <|
                let
                    levels =
                        [ ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMap pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0 ]
            , test "createPixelMap with Level 2" <|
                let
                    levels =
                        [ ( RecursivePattern.Level 2 2, RecursivePattern.Level 1 1 ), ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMap pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0, RecursivePattern.PixelPositon 1 0, RecursivePattern.PixelPositon 0 1, RecursivePattern.PixelPositon 1 1 ]
            ]
        , describe "createPixelMapTopDown"
            [ test "createPixelMapTopDown with empty Level" <|
                let
                    levels =
                        []

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMapTopDown pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0 ]
            , test "createPixelMapTopDown with Level" <|
                let
                    levels =
                        [ ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMapTopDown pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0 ]
            , test "createPixelMapTopDown with Level 2" <|
                let
                    levels =
                        [ ( RecursivePattern.Level 2 2, RecursivePattern.Level 1 1 ), ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMapTopDown pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0, RecursivePattern.PixelPositon 0 1, RecursivePattern.PixelPositon 1 0, RecursivePattern.PixelPositon 1 1 ]
            ]
        , describe "createPixelMapZ"
            [ test "createPixelMapZ with empty Level" <|
                let
                    levels =
                        []

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMapZ pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0 ]
            , test "createPixelMapZ with Level" <|
                let
                    levels =
                        [ ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMapZ pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0 ]
            , test "createPixelMapZ with Level 2" <|
                let
                    levels =
                        [ ( RecursivePattern.Level 3 3, RecursivePattern.Level 1 1 ), ( RecursivePattern.Level 1 1, RecursivePattern.Level 0 0 ) ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0
                in
                \() ->
                    RecursivePattern.createPixelMapZ pixelPositon levels
                        |> Expect.equal [ RecursivePattern.PixelPositon 0 0, RecursivePattern.PixelPositon 1 0, RecursivePattern.PixelPositon 2 0, RecursivePattern.PixelPositon 2 1, RecursivePattern.PixelPositon 1 1, RecursivePattern.PixelPositon 0 1, RecursivePattern.PixelPositon 0 2, RecursivePattern.PixelPositon 1 2, RecursivePattern.PixelPositon 2 2 ]
            ]
        ]
