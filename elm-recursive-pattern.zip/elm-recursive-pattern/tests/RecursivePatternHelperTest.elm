module RecursivePatternHelperTest exposing (..)

import Expect
import RecursivePattern
import RecursivePattern.Helper
import Scale exposing (ContinuousScale)
import Test exposing (..)
import TypedSvg.Attributes
import TypedSvg.Types exposing (px)

all : Test
all =
    describe "A Test Suite for RecursivePattern"
        [ describe "Helper Method"
            [ test "getW" <|
                let
                    level =
                        RecursivePattern.Level 1 2
                in
                \() ->
                    RecursivePattern.Helper.getW level
                        |> Expect.equal 1
            , test "getH" <|
                let
                    level =
                        RecursivePattern.Level 1 2
                in
                \() ->
                    RecursivePattern.Helper.getH level
                        |> Expect.equal 2
            ]
        , describe "drawTuplePosition"
            [ test "drawTuplePosition Typed Svg 1" <|
                let
                    levels =
                        [ RecursivePattern.Level 1 1 ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0

                    result =
                        [ TypedSvg.Attributes.x (px 0)
                        , TypedSvg.Attributes.y (px 0)
                        , TypedSvg.Attributes.width (px 10)
                        , TypedSvg.Attributes.height (px 10)
                        ]
                in
                \() ->
                    RecursivePattern.Helper.drawTuplePosition ( 10, 10 ) levels pixelPositon
                        |> Expect.equal result
            , test "drawTuplePosition Typed Svg 2" <|
                let
                    levels =
                        [ RecursivePattern.Level 1 1 ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 50 50

                    result =
                        [ TypedSvg.Attributes.x (px 50)
                        , TypedSvg.Attributes.y (px 50)
                        , TypedSvg.Attributes.width (px 1)
                        , TypedSvg.Attributes.height (px 1)
                        ]
                in
                \() ->
                    RecursivePattern.Helper.drawTuplePosition ( 1, 1 ) levels pixelPositon
                        |> Expect.equal result
            , test "drawTuplePosition Typed Svg 3" <|
                let
                    levels =
                        [ RecursivePattern.Level 2 2 ]

                    pixelPositon =
                        RecursivePattern.PixelPositon 0 0

                    result =
                        [ TypedSvg.Attributes.x (px 0)
                        , TypedSvg.Attributes.y (px 0)
                        , TypedSvg.Attributes.width (px 10)
                        , TypedSvg.Attributes.height (px 10)
                        ]
                in
                \() ->
                    RecursivePattern.Helper.drawTuplePosition ( 20, 20 ) levels pixelPositon
                        |> Expect.equal result
            ]
        ]

--, describe "Scale"
--    [ test "scaleWidth" <|
--        let
--           levels =
--                [ RecursivePattern.Level 1 1 ]
--        in
--        \() ->
--            RecursivePattern.Helper.scaleWidth 10 levels
--                |> Expect.equal (Scale.linear ( 0.0, 10.0 ) ( 0.0, 1.0 ))
--    , test "scaleWidth 1" <|
--        let
--            levels =
--                [ RecursivePattern.Level 2 2, RecursivePattern.Level 1 1 ]
--        in
--        \() ->
--            RecursivePattern.Helper.scaleWidth 100 levels
--                |> Expect.equal (Scale.linear ( 0.0, 100.0 ) ( 0.0, 2.0 ))
--    , test "scaleHeight" <|
--        let
--            levels =
--                [ RecursivePattern.Level 1 1 ]
--        in
--        \() ->
--            RecursivePattern.Helper.scaleHeight 10 levels
--                |> Expect.equal (Scale.linear ( 0.0, 10.0 ) ( 0.0, 1.0 ))
--    , test "scaleHeight 1" <|
--        let
--            levels =
--                [ RecursivePattern.Level 2 2, RecursivePattern.Level 1 1 ]
--        in
--        \() ->
--            RecursivePattern.Helper.scaleHeight 100 levels
--                |> Expect.equal (Scale.linear ( 0.0, 100.0 ) ( 0.0, 2.0 ))
--    ]